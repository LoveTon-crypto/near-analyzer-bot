# NEAR Analyzer Bot

- **Сканер токенов** (как в near-dex-bot): пришли адрес токена или ссылку nearly / JustHoot / DexScreener, или `/scan адрес` — цена, FDV, ATH, ликвидность, объём, топ-10 холдеров со ссылками на кошельки, свечной график 15m.
- **Алерты в темах группы**: DEX Paid (оплата профиля на DEX Screener + одобрение), бусты, CTO, реклама. Дальше: бондинг 25/50/75%, миграция, дипы.

## Установка на VPS (Termius)

```bash
cd /root
git clone https://github.com/LoveTon-crypto/near-analyzer-bot.git
cd near-analyzer-bot
printf 'BOT_TOKEN=ваш_токен\nPOLL_SECONDS=20\n' > .env
bash deploy.sh
```

## Обновление

Загрузи на GitHub новый `near-analyzer-bot.zip` (заменив старый) или сами файлы, потом:

```bash
analyzer-update
```

## Владелец

Первый, кто напишет боту `/start` в личке, становится владельцем: только он видит админ-панель (`/admin`) и может настраивать темы. Можно задать вручную строкой `OWNER_ID=ваш_id` в `.env`.

## Настройка группы

1. Группа → Настройки → включить «Темы».
2. Добавить бота админом.
3. В нужной теме отправить команду:

| Тема | Команда |
|---|---|
| DEX Paid | `/settopic dexpaid` |
| Бусты | `/settopic boost` |
| CTO | `/settopic cto` |
| Реклама | `/settopic ads` |

`/topics` — привязки, `/test dexpaid` — тестовый пост, `/unsettopic boost` — отвязать.

Сканер работает в любой теме и в личке с ботом. Под каждым алертом есть кнопка 🔎 Scan — она присылает полную карточку токена.
