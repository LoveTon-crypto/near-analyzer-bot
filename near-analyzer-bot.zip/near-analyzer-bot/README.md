# NEAR Analyzer Bot

Алерты для NEAR в темах Telegram-группы.

Сейчас: **DEX Paid** (оплата профиля на DEX Screener + одобрение), бусты, CTO, реклама.
Дальше: бондинг 25/50/75%, миграция, дипы.

Без зависимостей: нужен только Python 3 (на Ubuntu уже есть).

## Запуск на VPS (Termius)

```bash
cd /root
git clone https://github.com/LoveTon-crypto/near-analyzer-bot.git
cd near-analyzer-bot
cp .env.example .env
nano .env            # вставить BOT_TOKEN, сохранить: Ctrl+O, Enter, Ctrl+X
cp near-analyzer.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now near-analyzer
journalctl -u near-analyzer -f   # логи (выход: Ctrl+C)
```

Обновление: `cd /root/near-analyzer-bot && git pull && systemctl restart near-analyzer`

## Настройка группы

1. Создай группу → Настройки → включи «Темы».
2. Добавь бота и сделай админом (право «Управление темами» не нужно, достаточно отправки сообщений).
3. Открой нужную тему и напиши команду:

| Тема | Команда |
|---|---|
| DEX Paid | `/settopic dexpaid` |
| Бусты | `/settopic boost` |
| CTO | `/settopic cto` |
| Реклама | `/settopic ads` |

`/topics` — показать привязки, `/test dexpaid` — тестовый пост, `/unsettopic boost` — отвязать.

Если тема не привязана, бот просто не шлёт этот тип алертов.

При первом запуске бот запоминает токены, которые уже есть в ленте DEX Screener, и шлёт алерты только по новым.
