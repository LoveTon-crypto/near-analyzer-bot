#!/usr/bin/env python3
"""
NEAR Analyzer Bot
Posts alerts into topics of a Telegram forum group.

Topic 1 (live now): DEX Paid - a NEAR token paid for a DEX Screener profile.
Also available:     boosts, Community Takeover (CTO), DEX Screener ads.
Reserved for later: bonding 25/50/75 %, migration, dips.

Pure Python standard library - no pip install needed.
"""

import html
import json
import logging
import os
import sqlite3
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

# ---------------------------------------------------------------- config ---

def load_env(path=".env"):
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_env(os.path.join(BASE_DIR, ".env"))

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
DB_PATH = os.environ.get("DB_PATH", os.path.join(BASE_DIR, "analyzer.db"))
POLL_SECONDS = int(os.environ.get("POLL_SECONDS", "20"))
PENDING_RECHECK_SECONDS = int(os.environ.get("PENDING_RECHECK_SECONDS", "120"))
PENDING_MAX_HOURS = float(os.environ.get("PENDING_MAX_HOURS", "12"))
CHAIN = "near"

DS = "https://api.dexscreener.com"
TG = f"https://api.telegram.org/bot{BOT_TOKEN}"

# Topic keys the group can bind with /settopic <key>
TOPICS = {
    "dexpaid": "DEX Paid (paid DEX Screener profile)",
    "boost": "DEX Screener boosts",
    "cto": "Community Takeover (CTO)",
    "ads": "DEX Screener ads",
    # coming next:
    "25": "Bonding 25% (coming soon)",
    "50": "Bonding 50% (coming soon)",
    "75": "Bonding 75% (coming soon)",
    "migration": "Migration (coming soon)",
    "dip": "Dip alert -15% (coming soon)",
}

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
)
log = logging.getLogger("near-analyzer")

# ------------------------------------------------------------------- http ---

def http_json(url, data=None, timeout=20):
    headers = {"User-Agent": "near-analyzer-bot/1.0", "Accept": "application/json"}
    body = None
    if data is not None:
        body = json.dumps(data).encode()
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=body, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


def ds_get(path):
    try:
        return http_json(DS + path)
    except urllib.error.HTTPError as e:
        if e.code == 429:
            log.warning("DEX Screener rate limit, backing off")
            time.sleep(30)
        else:
            log.warning("DEX Screener %s -> HTTP %s", path, e.code)
    except Exception as e:  # network hiccups must never kill the bot
        log.warning("DEX Screener %s failed: %s", path, e)
    return None


def tg(method, **params):
    try:
        res = http_json(f"{TG}/{method}", data=params, timeout=40)
        if not res.get("ok"):
            log.warning("Telegram %s: %s", method, res)
        return res
    except urllib.error.HTTPError as e:
        try:
            detail = e.read().decode()
        except Exception:
            detail = ""
        log.warning("Telegram %s HTTP %s %s", method, e.code, detail)
        return {"ok": False, "description": detail}
    except Exception as e:
        log.warning("Telegram %s failed: %s", method, e)
        return {"ok": False, "description": str(e)}

# --------------------------------------------------------------- storage ---

class Store:
    def __init__(self, path):
        self.lock = threading.Lock()
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS topics (
                key TEXT PRIMARY KEY, chat_id INTEGER, thread_id INTEGER);
            CREATE TABLE IF NOT EXISTS seen (
                key TEXT PRIMARY KEY, ts INTEGER);
            CREATE TABLE IF NOT EXISTS pending (
                token TEXT, order_type TEXT, status TEXT,
                chat_id INTEGER, message_id INTEGER, created INTEGER,
                PRIMARY KEY (token, order_type));
            CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT);
        """)
        self.db.commit()

    def q(self, sql, args=()):
        with self.lock:
            cur = self.db.execute(sql, args)
            self.db.commit()
            return cur.fetchall()

    # topics
    def set_topic(self, key, chat_id, thread_id):
        self.q("REPLACE INTO topics VALUES (?,?,?)", (key, chat_id, thread_id))

    def get_topic(self, key):
        r = self.q("SELECT chat_id, thread_id FROM topics WHERE key=?", (key,))
        return r[0] if r else None

    def all_topics(self):
        return self.q("SELECT key, chat_id, thread_id FROM topics")

    # dedupe
    def seen(self, key):
        return bool(self.q("SELECT 1 FROM seen WHERE key=?", (key,)))

    def mark(self, key):
        self.q("INSERT OR IGNORE INTO seen VALUES (?,?)", (key, int(time.time())))

    # pending orders
    def add_pending(self, token, order_type, status, chat_id, message_id):
        self.q("REPLACE INTO pending VALUES (?,?,?,?,?,?)",
               (token, order_type, status, chat_id, message_id, int(time.time())))

    def pendings(self):
        return self.q("SELECT token, order_type, status, chat_id, message_id, created FROM pending")

    def drop_pending(self, token, order_type):
        self.q("DELETE FROM pending WHERE token=? AND order_type=?", (token, order_type))

    def kv_get(self, k):
        r = self.q("SELECT v FROM kv WHERE k=?", (k,))
        return r[0][0] if r else None

    def kv_set(self, k, v):
        self.q("REPLACE INTO kv VALUES (?,?)", (k, v))

# -------------------------------------------------------------- helpers ---

def fmt_usd(x):
    try:
        x = float(x)
    except (TypeError, ValueError):
        return "—"
    for div, suf in ((1e9, "B"), (1e6, "M"), (1e3, "K")):
        if abs(x) >= div:
            return f"${x / div:.1f}{suf}"
    return f"${x:.0f}" if x >= 1 else f"${x:.4g}"


def fmt_age(ms):
    if not ms:
        return "—"
    s = max(0, time.time() - ms / 1000)
    if s < 3600:
        return f"{int(s // 60)}m"
    if s < 86400:
        return f"{int(s // 3600)}h"
    return f"{int(s // 86400)}d"


def launchpad_of(addr):
    a = addr.lower()
    if a.endswith(".nearlytrade.near"):
        return "nearly", f"https://nearly.trade/{addr}"
    if a.endswith(".justhoot.near"):
        return "JustHoot", None
    if a.endswith("meme-cooking.near"):
        return "meme.cooking", None
    return None, None


ORDER_NAMES = {
    "tokenProfile": "Paid token profile",
    "communityTakeover": "Community Takeover",
    "tokenAd": "Token ad",
    "trendingBarAd": "Trending bar ad",
}

STATUS_ICONS = {
    "approved": "✅",
    "processing": "⏳",
    "on-hold": "⏸",
    "rejected": "❌",
    "cancelled": "🚫",
}


def get_orders(token):
    """Returns list of {type, status, paymentTimestamp}."""
    data = ds_get(f"/orders/v1/{CHAIN}/{urllib.parse.quote(token, safe='')}")
    if isinstance(data, dict):  # newer shape: {"orders": [...], "boosts": [...]}
        data = data.get("orders") or []
    return data if isinstance(data, list) else []


def best_pair(token):
    data = ds_get(f"/tokens/v1/{CHAIN}/{urllib.parse.quote(token, safe='')}")
    if isinstance(data, dict):
        data = data.get("pairs") or []
    if not isinstance(data, list) or not data:
        return None
    mine = [p for p in data
            if (p.get("baseToken") or {}).get("address", "").lower() == token.lower()] or data
    return max(mine, key=lambda p: (p.get("liquidity") or {}).get("usd") or 0)


def links_line(item, pair):
    out, seen_urls = [], set()

    def add(label, url):
        if url and url not in seen_urls:
            seen_urls.add(url)
            out.append(f'<a href="{html.escape(url, quote=True)}">{html.escape(label)}</a>')

    links = list(item.get("links") or [])
    info = (pair or {}).get("info") or {}
    for w in info.get("websites") or []:
        links.append({"label": w.get("label") or "Website", "url": w.get("url")})
    for s in info.get("socials") or []:
        links.append({"type": s.get("type"), "url": s.get("url")})

    for l in links:
        t = (l.get("type") or "").lower()
        label = {"twitter": "X", "telegram": "Telegram", "discord": "Discord"}.get(
            t, l.get("label") or "Website")
        add(label, l.get("url"))
    return " · ".join(out)


def token_card(token, item, pair):
    """Common body: name, stats, CA, links."""
    base = (pair or {}).get("baseToken") or {}
    sym = base.get("symbol") or token.split(".")[0].split("-")[0].upper()
    name = base.get("name") or ""
    pad, pad_url = launchpad_of(token)

    lines = [f"<b>${html.escape(sym)}</b>" + (f" — {html.escape(name)}" if name else "")]
    if pair:
        mc = pair.get("marketCap") or pair.get("fdv")
        liq = (pair.get("liquidity") or {}).get("usd")
        ch = (pair.get("priceChange") or {}).get("h24")
        stats = f"💰 MC: {fmt_usd(mc)} · 💧 Liq: {fmt_usd(liq)} · ⏱ {fmt_age(pair.get('pairCreatedAt'))}"
        if ch is not None:
            stats += f" · 24h: {ch:+.1f}%"
        lines.append(stats)
    if pad:
        lines.append(f"🚀 Launchpad: {pad}")
    lines.append(f"📄 CA: <code>{html.escape(token)}</code>")

    ll = links_line(item, pair)
    if ll:
        lines.append(f"🔗 {ll}")

    ds_url = item.get("url") or (pair or {}).get("url") or f"https://dexscreener.com/{CHAIN}/{token}"
    bottom = [f'<a href="{html.escape(ds_url, quote=True)}">DEX Screener</a>']
    if pad_url:
        bottom.append(f'<a href="{pad_url}">Trade on nearly</a>')
    bottom.append(f'<a href="https://nearblocks.io/token/{urllib.parse.quote(token)}">NearBlocks</a>')
    lines.append("📊 " + " · ".join(bottom))
    return lines


def image_of(item, pair):
    info = (pair or {}).get("info") or {}
    return item.get("header") or info.get("header") or item.get("icon") or info.get("imageUrl")

# ------------------------------------------------------------ the bot ---

class Bot:
    def __init__(self):
        self.store = Store(DB_PATH)
        self.offset = 0
        self.me = None

    # ---------- sending ----------
    def send(self, topic_key, text, image=None, reply_to=None):
        t = self.store.get_topic(topic_key)
        if not t:
            log.info("No topic bound for %s, skipping alert", topic_key)
            return None
        chat_id, thread_id = t
        common = {"chat_id": chat_id, "parse_mode": "HTML"}
        if thread_id:
            common["message_thread_id"] = thread_id
        if reply_to:
            common["reply_parameters"] = {"message_id": reply_to, "allow_sending_without_reply": True}

        res = None
        if image and len(text) <= 1024:
            res = tg("sendPhoto", photo=image, caption=text, **common)
        if not res or not res.get("ok"):
            res = tg("sendMessage", text=text, link_preview_options={"is_disabled": True}, **common)
        if res and res.get("ok"):
            return chat_id, res["result"]["message_id"]
        return None

    # ---------- DEX Paid ----------
    def handle_profile(self, item, silent=False):
        token = item.get("tokenAddress")
        if not token:
            return
        key = f"profile:{token}"
        if self.store.seen(key):
            return
        self.store.mark(key)
        if silent:
            return

        orders = get_orders(token)
        prof = [o for o in orders if o.get("type") == "tokenProfile"] or \
               [{"type": "tokenProfile", "status": "approved"}]
        o = prof[0]
        status = o.get("status") or "approved"
        pair = best_pair(token)

        head = f"💎 <b>DEX PAID</b> {STATUS_ICONS.get(status, '•')} {status.upper()}"
        lines = [head, ""] + token_card(token, item, pair)
        paid_ts = o.get("paymentTimestamp")
        if paid_ts:
            lines.append(f"🕒 Paid {fmt_age(paid_ts)} ago")
        other = [x for x in orders if x.get("type") != "tokenProfile" and x.get("status") == "approved"]
        if other:
            lines.append("➕ Also paid: " + ", ".join(ORDER_NAMES.get(x["type"], x["type"]) for x in other))

        sent = self.send("dexpaid", "\n".join(lines), image_of(item, pair))
        log.info("DEX paid alert %s (%s)", token, status)
        if sent and status in ("processing", "on-hold"):
            self.store.add_pending(token, "tokenProfile", status, sent[0], sent[1])

    def recheck_pending(self):
        now = time.time()
        for token, otype, old, chat_id, msg_id, created in self.store.pendings():
            if now - created > PENDING_MAX_HOURS * 3600:
                self.store.drop_pending(token, otype)
                continue
            orders = [o for o in get_orders(token) if o.get("type") == otype]
            if not orders:
                continue
            new = orders[0].get("status")
            if new and new != old:
                icon = STATUS_ICONS.get(new, "•")
                sym = token.split(".")[0].split("-")[0].upper()
                text = (f"{icon} <b>{ORDER_NAMES.get(otype, otype)} {new}</b> by DEX Screener\n"
                        f"<code>{html.escape(token)}</code> (${html.escape(sym)})")
                self.send("dexpaid", text, reply_to=msg_id)
                if new in ("processing", "on-hold"):
                    self.store.add_pending(token, otype, new, chat_id, msg_id)
                else:
                    self.store.drop_pending(token, otype)

    # ---------- boosts / CTO / ads ----------
    def handle_boost(self, item, silent=False):
        token = item.get("tokenAddress")
        total = item.get("totalAmount") or item.get("amount")
        key = f"boost:{token}:{total}"
        if not token or self.store.seen(key):
            return
        self.store.mark(key)
        if silent:
            return
        pair = best_pair(token)
        lines = [f"⚡ <b>BOOST</b> +{item.get('amount', '?')} (total {total})", ""] + token_card(token, item, pair)
        self.send("boost", "\n".join(lines), image_of(item, pair))

    def handle_cto(self, item, silent=False):
        token = item.get("tokenAddress")
        key = f"cto:{token}"
        if not token or self.store.seen(key):
            return
        self.store.mark(key)
        if silent:
            return
        pair = best_pair(token)
        lines = ["🏴 <b>COMMUNITY TAKEOVER</b> approved", ""] + token_card(token, item, pair)
        self.send("cto", "\n".join(lines), image_of(item, pair))

    def handle_ad(self, item, silent=False):
        token = item.get("tokenAddress")
        key = f"ad:{token}:{item.get('date')}:{item.get('type')}"
        if not token or self.store.seen(key):
            return
        self.store.mark(key)
        if silent:
            return
        pair = best_pair(token)
        dur = item.get("durationHours")
        head = f"📢 <b>DEX SCREENER AD</b> ({item.get('type', 'ad')}" + (f", {dur}h" if dur else "") + ")"
        lines = [head, ""] + token_card(token, item, pair)
        self.send("ads", "\n".join(lines), image_of(item, pair))

    FEEDS = (
        ("/token-profiles/latest/v1", "handle_profile"),
        ("/token-boosts/latest/v1", "handle_boost"),
        ("/community-takeovers/latest/v1", "handle_cto"),
        ("/ads/latest/v1", "handle_ad"),
    )

    def poll_feeds(self, silent=False):
        for path, handler in self.FEEDS:
            data = ds_get(path)
            if isinstance(data, dict):
                data = [data]
            if not isinstance(data, list):
                continue
            for item in data:
                if (item.get("chainId") or "").lower() != CHAIN:
                    continue
                try:
                    getattr(self, handler)(item, silent=silent)
                except Exception:
                    log.exception("handler %s failed", handler)

    def watcher_loop(self):
        # First run: remember what is already in the feeds so we don't spam old tokens.
        if not self.store.kv_get("seeded"):
            log.info("First start: seeding current feeds without alerts")
            self.poll_feeds(silent=True)
            self.store.kv_set("seeded", "1")
        last_recheck = 0
        while True:
            try:
                self.poll_feeds()
                if time.time() - last_recheck > PENDING_RECHECK_SECONDS:
                    self.recheck_pending()
                    last_recheck = time.time()
            except Exception:
                log.exception("watcher loop error")
            time.sleep(POLL_SECONDS)

    # ---------- commands ----------
    def is_admin(self, chat_id, user_id):
        res = tg("getChatMember", chat_id=chat_id, user_id=user_id)
        st = ((res or {}).get("result") or {}).get("status")
        return st in ("creator", "administrator")

    def reply(self, msg, text):
        p = {"chat_id": msg["chat"]["id"], "text": text, "parse_mode": "HTML",
             "reply_parameters": {"message_id": msg["message_id"], "allow_sending_without_reply": True}}
        if msg.get("message_thread_id"):
            p["message_thread_id"] = msg["message_thread_id"]
        tg("sendMessage", **p)

    def handle_message(self, msg):
        text = (msg.get("text") or "").strip()
        if not text.startswith("/"):
            return
        parts = text.split()
        cmd = parts[0].split("@")[0].lower()
        args = parts[1:]
        chat = msg["chat"]
        user = msg.get("from") or {}

        if cmd in ("/start", "/help"):
            keys = "\n".join(f"<code>{k}</code> — {v}" for k, v in TOPICS.items())
            self.reply(msg,
                "<b>NEAR Analyzer</b>\n\n"
                "Add me to a forum group as admin, open a topic and send\n"
                "<code>/settopic dexpaid</code>\n\nTopic keys:\n" + keys +
                "\n\n/topics — show bindings\n/unsettopic &lt;key&gt; — remove\n/test &lt;key&gt; — test post")
            return

        if chat.get("type") not in ("group", "supergroup"):
            return

        if cmd in ("/settopic", "/unsettopic", "/test") and not self.is_admin(chat["id"], user.get("id")):
            self.reply(msg, "Only group admins can do this.")
            return

        if cmd == "/settopic":
            if not args or args[0].lower() not in TOPICS:
                self.reply(msg, "Usage: <code>/settopic dexpaid</code>\nKeys: " + ", ".join(TOPICS))
                return
            key = args[0].lower()
            thread = msg.get("message_thread_id") if msg.get("is_topic_message") else None
            self.store.set_topic(key, chat["id"], thread)
            where = "this topic" if thread else "the General chat"
            self.reply(msg, f"✅ <b>{html.escape(TOPICS[key])}</b> alerts will be posted in {where}.")
        elif cmd == "/unsettopic":
            if args:
                self.store.q("DELETE FROM topics WHERE key=?", (args[0].lower(),))
                self.reply(msg, f"Removed <code>{html.escape(args[0])}</code>.")
        elif cmd == "/topics":
            rows = self.store.all_topics()
            if not rows:
                self.reply(msg, "No topics bound yet. Use /settopic in a topic.")
            else:
                self.reply(msg, "\n".join(
                    f"<code>{k}</code> → topic {t or 'General'}" for k, _, t in rows))
        elif cmd == "/test":
            key = (args[0].lower() if args else "dexpaid")
            if not self.store.get_topic(key):
                self.reply(msg, f"Topic <code>{html.escape(key)}</code> is not bound.")
            else:
                self.send(key, f"🧪 Test alert for <b>{html.escape(TOPICS.get(key, key))}</b>")

    def updates_loop(self):
        while True:
            res = tg("getUpdates", offset=self.offset, timeout=30,
                     allowed_updates=["message"])
            if not res or not res.get("ok"):
                time.sleep(5)
                continue
            for u in res.get("result", []):
                self.offset = u["update_id"] + 1
                msg = u.get("message")
                if msg:
                    try:
                        self.handle_message(msg)
                    except Exception:
                        log.exception("command failed")

    def run(self):
        if not BOT_TOKEN:
            raise SystemExit("BOT_TOKEN is not set (put it in .env)")
        me = tg("getMe")
        if not me.get("ok"):
            raise SystemExit(f"Bad BOT_TOKEN: {me}")
        log.info("Started as @%s", me["result"]["username"])
        threading.Thread(target=self.watcher_loop, daemon=True).start()
        self.updates_loop()


if __name__ == "__main__":
    Bot().run()
