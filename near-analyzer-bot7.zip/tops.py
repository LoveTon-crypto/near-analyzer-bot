"""Top lists: /top (memepads by 24h volume), /topmc (memepads by market cap), /topdex (trending on NEAR).

DexScreener has no public API for its "Hot" tab, so /topdex uses GeckoTerminal's trending pools for NEAR
(free, same idea: ranked by recent activity and volume).
"""
from __future__ import annotations

import html
import time

import httpx

GT = "https://api.geckoterminal.com/api/v2/networks/near/trending_pools"
_cache: dict[str, tuple[float, list]] = {}


def f(x) -> float:
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def usd(x: float) -> str:
    for div, suf in ((1e9, "B"), (1e6, "M"), (1e3, "K")):
        if abs(x) >= div:
            return f"${x / div:.1f}{suf}"
    return f"${x:,.0f}"


async def trending(client: httpx.AsyncClient) -> list[dict]:
    hit = _cache.get("gt")
    if hit and time.time() - hit[0] < 120:
        return hit[1]
    rows = []
    try:
        r = await client.get(GT, params={"include": "base_token", "page": 1},
                             headers={"Accept": "application/json;version=20230302"})
        payload = r.json() if r.status_code == 200 else {}
    except (httpx.HTTPError, ValueError):
        payload = {}
    inc = {i["id"]: i.get("attributes", {}) for i in payload.get("included", []) or []}
    for d in payload.get("data") or []:
        a = d.get("attributes", {})
        base_id = (((d.get("relationships") or {}).get("base_token") or {}).get("data") or {}).get("id", "")
        base = inc.get(base_id, {})
        rows.append(dict(address=base.get("address") or base_id.split("_", 1)[-1],
                         symbol=base.get("symbol") or (a.get("name") or "?").split("/")[0].strip(),
                         name=base.get("name") or "",
                         fdv=f(a.get("market_cap_usd") or a.get("fdv_usd")),
                         vol=f((a.get("volume_usd") or {}).get("h24")),
                         liq=f(a.get("reserve_in_usd")),
                         change=f((a.get("price_change_percentage") or {}).get("h24")),
                         pool=a.get("address", "")))
    seen, uniq = set(), []
    for r in rows:  # one line per token even if several of its pools trend
        if r["address"] not in seen and r["symbol"].upper() not in ("WNEAR", "NEAR", "USDC", "USDT"):
            seen.add(r["address"])
            uniq.append(r)
    if uniq:
        _cache["gt"] = (time.time(), uniq)
    return uniq or (hit[1] if hit else [])


TITLES = {"vol": "📊 <b>Top 10 memepads · 24h volume</b>",
          "mc": "💰 <b>Top 10 memepads · market cap</b>",
          "hot": "🔥 <b>Top 10 trending on NEAR</b>"}


def fmt(kind: str, rows: list[dict], link, pad_name) -> str:
    lines = [TITLES[kind], "<i>nearly + JustHoot</i>" if kind != "hot" else "<i>GeckoTerminal trending</i>", ""]
    if not rows:
        lines.append("No data yet — try again in a minute.")
    medals = ["🥇", "🥈", "🥉"] + [f"{i}." for i in range(4, 11)]
    for i, r in enumerate(rows[:10]):
        ch = r["change"]
        arrow = "🟢" if ch >= 0 else "🔴"
        main = f"Vol <b>{usd(r['vol'])}</b> · MC {usd(r['fdv'])}" if kind == "vol" else \
            f"MC <b>{usd(r['fdv'])}</b> · Vol {usd(r['vol'])}" if kind == "mc" else \
            f"MC {usd(r['fdv'])} · Vol <b>{usd(r['vol'])}</b>"
        pad = pad_name(r["address"])
        lines.append(f'{medals[i]} <a href="{html.escape(link(r), quote=True)}"><b>${html.escape(r["symbol"][:12])}</b></a>'
                     f' {arrow} {ch:+.0f}%' + (f" · {pad}" if pad and kind == "hot" else ""))
        lines.append(f"     {main}")
    lines.append("\n<i>Tap a token to open it · send its contract to scan</i>")
    return "\n".join(lines)
