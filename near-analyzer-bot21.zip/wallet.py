"""Wallet PnL ("Inspect Wallet") for any NEAR account.

Data: Intear API (https://api.intea.rs, free during beta, no key):
  • /positions — every token position built from the wallet's swaps: bought/sold USD, realized PnL, amount left
  • /trades    — swaps of the last 7 days (for the 7d block)
  • /balances  — tokens held now + prices (to value what's still held)
NEAR balance comes from public NEAR RPC (no FastNear key used).
"""
from __future__ import annotations

import asyncio
import base64
import html
import json
import logging
import time

import httpx

log = logging.getLogger("wallet")

INTEAR = "https://api.intea.rs"
DEXS = "https://api.dexscreener.com"
RPC_URLS = ["https://rpc.mainnet.fastnear.com", "https://free.rpc.fastnear.com", "https://rpc.mainnet.near.org"]
# quote tokens — not "positions" in the memecoin sense
BASES = {"wrap.near", "near", "usdt.tether-token.near",
         "17208628f84f5d6ad33f0da3bbbeb27ffcb398eac501a31bd6ad2011e36133a1",  # USDC
         "a0b86991c6218b36c1d19d4a2e9eb0ce3606eb48.factory.bridge.near",       # USDC.e
         "dac17f958d2ee523a2206206994597c13d831ec7.factory.bridge.near"}       # USDT.e


def _table(data) -> list[dict]:
    """Intear answers {result: {columns, rows}} (or the inner object directly); rows may be lists or dicts."""
    if isinstance(data, dict) and "result" in data:
        data = data["result"]
    if isinstance(data, list):
        return [r for r in data if isinstance(r, dict)]
    if not isinstance(data, dict):
        return []
    rows = data.get("rows") or data.get("positions") or data.get("trades") or []
    cols = data.get("columns") or []
    out = []
    for r in rows:
        if isinstance(r, dict):
            out.append(r)
        elif isinstance(r, list) and cols:
            out.append(dict(zip(cols, r)))
    return out


def token_url(t: str) -> str:
    if t.endswith(".nearlytrade.near"):
        return f"https://nearly.trade/{t}"
    if t.endswith("launchpad.justhoot.near"):
        return f"https://justhoot.fun/p/{t}"
    return f"https://nearblocks.io/token/{t}"


def f(x) -> float:
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def money(x: float) -> str:
    sign = "-" if x < 0 else ""
    x = abs(x)
    for div, suf in ((1e9, "B"), (1e6, "M"), (1e3, "K")):
        if x >= div:
            return f"{sign}${x / div:.2f}".rstrip("0").rstrip(".") + suf
    return f"{sign}${x:,.2f}"


def signed(x: float) -> str:
    return ("+" if x >= 0 else "") + money(x)


def nears(x_usd: float, near_usd: float) -> str:
    if near_usd <= 0:
        return ""
    v = x_usd / near_usd
    return f" <i>≈{v:,.0f} Ⓝ</i>" if abs(v) >= 100 else f" <i>≈{v:,.1f} Ⓝ</i>"


class WalletPnL:
    def __init__(self, http: httpx.AsyncClient):
        self.http = http
        self._sym: dict[str, str] = {}
        self._dec: dict[str, int] = {}

    async def _get(self, path: str, params: dict, timeout: float = 25):
        try:
            r = await self.http.get(f"{INTEAR}{path}", params=params, timeout=timeout)
        except httpx.HTTPError as e:
            log.info("intear %s: %s", path, e)
            return None
        if r.status_code >= 400:
            log.info("intear %s -> HTTP %s %s", path, r.status_code, r.text[:200])
            return None
        try:
            return r.json()
        except ValueError:
            return None

    async def _rpc(self, params: dict):
        payload = {"jsonrpc": "2.0", "id": "1", "method": "query", "params": params}
        for url in RPC_URLS:
            try:
                data = (await self.http.post(url, json=payload, timeout=10)).json()
            except (httpx.HTTPError, ValueError):
                continue
            if "result" in data:
                return data["result"]
            if "UNKNOWN_ACCOUNT" in json.dumps(data.get("error") or ""):
                return None
        return None

    async def account(self, acc: str):
        res = await self._rpc({"request_type": "view_account", "finality": "final", "account_id": acc})
        return res if isinstance(res, dict) and "amount" in res else None

    async def symbol(self, token: str) -> str:
        if token in self._sym:
            return self._sym[token]
        res = await self._rpc({"request_type": "call_function", "finality": "final", "account_id": token,
                               "method_name": "ft_metadata", "args_base64": base64.b64encode(b"{}").decode()})
        sym = ""
        try:
            sym = str(json.loads(bytes(res["result"]).decode()).get("symbol") or "")[:16]
        except (TypeError, KeyError, ValueError, AttributeError):
            pass
        sym = sym or token.split(".")[0].upper()[:16]
        self._sym[token] = sym
        return sym

    async def positions(self, acc: str) -> list[dict] | None:
        data = await self._get("/positions", {"account": acc, "limit": 1000})
        return None if data is None else _table(data)

    async def _view(self, account: str, method: str, args: dict | None = None):
        res = await self._rpc({"request_type": "call_function", "finality": "final", "account_id": account,
                               "method_name": method,
                               "args_base64": base64.b64encode(json.dumps(args or {}).encode()).decode()})
        try:
            return json.loads(bytes(res["result"]).decode())
        except (TypeError, KeyError, ValueError, AttributeError):
            return None

    async def _decimals(self, token: str) -> int | None:
        if token in self._dec:
            return self._dec[token]
        meta = await self._view(token, "ft_metadata")
        if not isinstance(meta, dict):
            return None
        self._dec[token] = int(f(meta.get("decimals")))
        if meta.get("symbol"):
            self._sym.setdefault(token, str(meta["symbol"])[:16])
        return self._dec[token]

    async def _rpc_amount(self, acc: str, token: str) -> float:
        raw, dec = await asyncio.gather(self._view(token, "ft_balance_of", {"account_id": acc}),
                                        self._decimals(token))
        return f(raw) / 10 ** dec if dec is not None else 0.0

    async def dex_prices(self, tokens: list[str]) -> dict[str, float]:
        """USD price from DexScreener (the pair with the most liquidity), 30 tokens per request."""
        out: dict[str, tuple[float, float]] = {}
        for i in range(0, len(tokens), 30):
            try:
                r = await self.http.get(f"{DEXS}/tokens/v1/near/" + ",".join(tokens[i:i + 30]), timeout=15)
                data = r.json() if r.status_code < 400 else []
            except (httpx.HTTPError, ValueError):
                continue
            for p in data if isinstance(data, list) else []:
                a = (p.get("baseToken") or {}).get("address")
                liq = f((p.get("liquidity") or {}).get("usd"))
                if a and f(p.get("priceUsd")) > 0 and liq >= out.get(a, (0, -1))[1]:
                    out[a] = (f(p.get("priceUsd")), liq)
        return {a: v[0] for a, v in out.items()}

    async def holdings(self, acc: str, extra_tokens: set[str]) -> dict[str, float]:
        """token -> USD value held now. Amounts: Intear balances, checked on-chain for tokens Intear
        doesn't price/list; prices: Intear, else DexScreener."""
        data = await self._get("/balances", {"account": acc, "sources": "direct",
                                             "token_fields": "symbol,decimals,price_usd"})
        if isinstance(data, dict) and "result" in data:
            data = data["result"]
        amounts: dict[str, float] = {}
        prices: dict[str, float] = {}
        if isinstance(data, dict):
            toks = data.get("tokens") or {}
            for r in _table(data.get("balances") or []):
                t = r.get("token")
                if not t:
                    continue
                meta = toks.get(t) or {}
                if meta.get("symbol"):
                    self._sym[t] = str(meta["symbol"])[:16]
                if meta.get("decimals") not in (None, ""):
                    self._dec[t] = int(f(meta["decimals"]))
                    amounts[t] = amounts.get(t, 0.0) + f(r.get("balance")) / 10 ** self._dec[t]
                if f(meta.get("price_usd")) > 0:
                    prices[t] = f(meta["price_usd"])
        # tokens from the trade history that Intear didn't report: read the balance on-chain
        missing = [t for t in extra_tokens if t not in amounts][:60]
        if missing:
            vals = await asyncio.gather(*(self._rpc_amount(acc, t) for t in missing))
            amounts.update({t: v for t, v in zip(missing, vals) if v > 0})
        unpriced = [t for t, a in amounts.items() if a > 0 and t not in prices]
        if unpriced:
            prices.update(await self.dex_prices(unpriced))
        return {t: a * prices.get(t, 0.0) for t, a in amounts.items()}

    async def trades_7d(self, acc: str) -> list[dict]:
        since = int((time.time() - 7 * 86400) * 1000)
        rows, cursor = [], None
        for _ in range(10):  # up to 2000 swaps
            params = {"trader": acc, "after_millis": since, "limit": 200, "order": "desc",
                      "fields": "id,side,token,usd_value,timestamp_millis"}
            if cursor:
                params["cursor"] = cursor
            data = await self._get("/trades", params)
            if data is None:
                break
            inner = data.get("result", data) if isinstance(data, dict) else {}
            rows += _table(data)
            cursor = inner.get("next_cursor") if isinstance(inner, dict) else None
            if not cursor:
                break
        return rows

    # ------------------------------------------------------------------
    async def report(self, acc: str, near_usd: float) -> str | None:
        """HTML text of the wallet report, or None if the account doesn't exist."""
        info = await self.account(acc)
        if info is None:
            return None
        pos, tr7 = await asyncio.gather(self.positions(acc), self.trades_7d(acc))
        open_tokens = {p["token"] for p in (pos or [])
                       if p.get("token") and (p.get("closed_at_millis") is None or f(p.get("amount")) > 0)}
        hv = await self.holdings(acc, open_tokens - BASES)
        bals = {t: (v, self._sym.get(t, "")) for t, v in hv.items()}
        near_bal = f(info.get("amount")) / 1e24
        e = html.escape
        held_value = sum(v for t, (v, _) in bals.items() if t not in BASES)
        wnear = bals.get("wrap.near", (0.0, ""))[0]

        lines = ["🔎 <b>Inspect Wallet</b>", "",
                 f'👛 Wallet: <a href="https://nearblocks.io/address/{e(acc)}"><code>{e(acc)}</code></a>',
                 f"Ⓝ NEAR: <b>{near_bal:,.2f}</b>" + (f" ≈ {money(near_bal * near_usd)}" if near_usd else "")
                 + (f" (+ {money(wnear)} wNEAR)" if wnear >= 1 else ""),
                 f"💰 Tokens value: <b>{money(held_value)}</b>"]

        if pos is None:
            lines += ["", "⚠️ Trade history service is not answering right now, try again in a minute."]
            return "\n".join(lines)

        pos = [p for p in pos if p.get("token") and p["token"] not in BASES]
        if not pos:
            lines += ["", "🤷 No swaps found for this wallet."]
            return "\n".join(lines)

        # ----- all time
        # Intear opens a new position every time the wallet re-enters a token → merge them per token,
        # and count what's held now only once per token.
        merged: dict[str, dict] = {}
        for p in pos:
            m = merged.setdefault(p["token"], {"bought_usd": 0.0, "sold_usd": 0.0, "realized_pnl_usd": 0.0,
                                               "buys": 0, "sells": 0})
            for k in ("bought_usd", "sold_usd", "realized_pnl_usd"):
                m[k] += f(p.get(k))
            for k in ("buys", "sells"):
                m[k] += int(f(p.get(k)))
        rows = []
        for t, m in merged.items():
            hold = bals.get(t, (0.0, ""))[0]
            b, s = m["bought_usd"], m["sold_usd"]
            rows.append((t, b, s, hold, s + hold - b, m))
        B = sum(r[1] for r in rows)
        S = sum(r[2] for r in rows)
        Hh = sum(r[3] for r in rows)
        P = S + Hh - B
        realized = sum(f(r[5].get("realized_pnl_usd")) for r in rows)
        wins = sum(1 for r in rows if r[4] > 0)
        traded = [r for r in rows if r[1] > 0]
        buys = sum(int(f(r[5].get("buys"))) for r in rows)
        sells = sum(int(f(r[5].get("sells"))) for r in rows)
        lines += ["", "🚀 <b>Total PnL</b>", "<blockquote>"
                  f"📥 Bought: <b>{money(B)}</b>{nears(B, near_usd)}\n"
                  f"📦 Hold: <b>{money(Hh)}</b>{nears(Hh, near_usd)}\n"
                  f"✅ Sold: <b>{money(S)}</b>{nears(S, near_usd)}\n"
                  f"{'🟢' if P >= 0 else '🔴'} PnL: <b>{signed(P)}</b>"
                  + (f" <b>{P / B * 100:+.0f}%</b>" if B > 0 else "") + "\n"
                  f"💵 Realized: {signed(realized)} · Unrealized: {signed(P - realized)}\n"
                  f"🎯 Win rate: <b>{wins}/{len(traded)}</b> tokens"
                  + (f" ({wins / len(traded) * 100:.0f}%)" if traded else "")
                  + f" · {buys} buys / {sells} sells</blockquote>"]

        # ----- 7 days
        if tr7:
            b7 = sum(f(x.get("usd_value")) for x in tr7 if str(x.get("side")).lower() == "buy")
            s7 = sum(f(x.get("usd_value")) for x in tr7 if str(x.get("side")).lower() == "sell")
            toks7 = {x.get("token") for x in tr7 if str(x.get("side")).lower() == "buy"} - BASES
            h7 = sum(bals.get(t, (0.0, ""))[0] for t in toks7)
            p7 = s7 + h7 - b7
            lines += ["😬 <b>7d PnL</b>" if p7 < 0 else "😎 <b>7d PnL</b>", "<blockquote>"
                      f"📥 Bought: <b>{money(b7)}</b>{nears(b7, near_usd)}\n"
                      f"📦 Hold: <b>{money(h7)}</b>{nears(h7, near_usd)}\n"
                      f"✅ Sold: <b>{money(s7)}</b>{nears(s7, near_usd)}\n"
                      f"{'🟢' if p7 >= 0 else '🔴'} PnL: <b>{signed(p7)}</b>"
                      + (f" <b>{p7 / b7 * 100:+.0f}%</b>" if b7 > 0 else "")
                      + f" · {len(tr7)} swaps</blockquote>"]
        else:
            lines += ["😴 <b>7d PnL</b>: no swaps in the last 7 days"]

        # ----- best / worst tokens
        ranked = sorted(traded, key=lambda r: r[4], reverse=True)
        best = [r for r in ranked if r[4] > 0][:3]
        worst = [r for r in reversed(ranked) if r[4] < 0][:3]
        syms = await asyncio.gather(*(self.symbol(r[0]) for r in best + worst))
        clean = lambda x: "".join(ch for ch in str(x) if ch.isprintable() and not ch.isspace()) or "?"
        sm = {t: clean(v) for t, v in zip([r[0] for r in best + worst], syms)}
        keys = [v.upper() for v in sm.values()]
        dup = {v for v in sm.values() if keys.count(v.upper()) > 1}

        def label(t: str) -> str:
            sym = sm[t]
            if sym in dup:  # same ticker, different contracts → show which one
                sym += "·" + t.split(".")[0][:12]
            return f'<a href="{e(token_url(t))}">${e(sym)}</a>'

        def item(r) -> str:
            return f"{label(r[0])} {signed(r[4])}" + (f" ({r[4] / r[1] * 100:+.0f}%)" if r[1] else "")

        if best:
            lines.append("🏆 Best: " + " · ".join(item(r) for r in best))
        if worst:
            lines.append("💀 Worst: " + " · ".join(item(r) for r in worst))
        lines.append("<i>USD at trade time · Hold = current value</i>")
        return "\n".join(lines)
