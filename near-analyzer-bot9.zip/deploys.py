"""New token deploys on NEAR memepads (nearly / JustHoot) → Telegram channel, like TON "TOPBLAST DEPLOY!" posts.

How it works:
  • Reads every NEAR block from neardata.xyz (free, no key) and catches the moment a memepad factory
    creates a new token account: X.nearlytrade.near, X.launchpad.justhoot.near, X.v2-launchpad.justhoot.near.
  • Dev = the account that signed the deploy transaction.
  • Post: token icon, name / ticker / description, dev's NEAR balance, how much of the token the dev holds,
    the dev's previous deploys and the best ATH market cap any of them reached.
  • Button "Buy" opens Bettear with the owner's referral code already in the link.

Dev history is stored in the bot's database from the moment the feed starts. BACKFILL_DAYS=N in .env
also scans the last N days of blocks once in the background, so older deploys are counted too.
"""
from __future__ import annotations

import asyncio
import base64
import html
import json
import logging
import os
import re
import time

import httpx
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, LinkPreviewOptions
from telegram.constants import ParseMode

from scanner import usd

log = logging.getLogger("deploys")

NEARDATA = os.environ.get("NEARDATA_URL", "https://mainnet.neardata.xyz").rstrip("/")
RPC_URLS = ["https://rpc.mainnet.fastnear.com", "https://free.rpc.fastnear.com", "https://rpc.mainnet.near.org"]
DEXS = "https://api.dexscreener.com"
NEARBLOCKS = "https://api.nearblocks.io"
NEARBLOCKS_KEY = os.environ.get("NEARBLOCKS_KEY", "")  # optional, free key from nearblocks.io raises limits

# factory account -> (label in the post, token page link)
FACTORIES = {
    "nearlytrade.near": ("NEARLY", "https://nearly.trade/{a}"),
    "launchpad.justhoot.near": ("JUSTHOOT", "https://justhoot.fun/p/{a}"),
    "v2-launchpad.justhoot.near": ("JUSTHOOT", "https://justhoot.fun/p/{a}"),
}
for _f in filter(None, (x.strip() for x in os.environ.get("DEPLOY_EXTRA_FACTORIES", "").split(","))):
    FACTORIES.setdefault(_f, (_f.split(".")[0].upper(), "https://nearblocks.io/token/{a}"))

BETTEAR_BOT = os.environ.get("BETTEAR_BOT", "bettearbot")
BETTEAR_REF = os.environ.get("BETTEAR_REF", "ref-1094156325")
DEPLOY_DELAY = int(os.environ.get("DEPLOY_DELAY", "12"))        # seconds after deploy: let metadata / dev buy land
MAX_LAG_BLOCKS = int(os.environ.get("DEPLOY_MAX_LAG", "900"))    # further behind than this → jump to the head
BACKFILL_DAYS = float(os.environ.get("BACKFILL_DAYS", "0"))
ATH_TRACK_DAYS = float(os.environ.get("DEPLOY_ATH_DAYS", "30"))
SECONDS_PER_BLOCK = 0.6
NO_PREVIEW = LinkPreviewOptions(is_disabled=True)
START_OK = re.compile(r"^[A-Za-z0-9_=-]{1,64}$")  # ?start= limit: 64 chars; '=' works with Bettear


def factory_of(account: str) -> str | None:
    """X.<factory> where X has no dots → the factory, else None."""
    for fac in FACTORIES:
        if account.endswith("." + fac) and "." not in account[: -len(fac) - 1]:
            return fac
    return None


def buy_link(token: str) -> str:
    """Bettear deep link with the referral code: dots in the contract become '='."""
    param = f"{BETTEAR_REF}-buy-{token.replace('.', '=')}"
    if not START_OK.match(param):  # too long or odd characters → plain referral link
        param = BETTEAR_REF
    return f"https://t.me/{BETTEAR_BOT}?start={param}"


def parse_block(blk: dict) -> list[dict]:
    """Memepad token-account creations in a neardata block."""
    out = []
    try:
        ts = int(((blk.get("block") or {}).get("header") or {}).get("timestamp") or 0) / 1e9
    except (TypeError, ValueError):
        ts = 0
    for shard in blk.get("shards") or []:
        for reo in shard.get("receipt_execution_outcomes") or []:
            r = reo.get("receipt") or {}
            token = r.get("receiver_id") or ""
            fac = factory_of(token)
            if not fac:
                continue
            act = (r.get("receipt") or {}).get("Action")
            if not isinstance(act, dict):
                continue
            actions = act.get("actions") or []
            if not any(a == "CreateAccount" or (isinstance(a, dict) and "CreateAccount" in a) for a in actions):
                continue
            status = ((reo.get("execution_outcome") or {}).get("outcome") or {}).get("status") or {}
            if isinstance(status, dict) and "Failure" in status:
                continue
            out.append({"token": token, "factory": fac, "signer": act.get("signer_id") or "",
                        "predecessor": r.get("predecessor_id") or "", "ts": ts or time.time(),
                        "tx": reo.get("tx_hash") or ""})
    return out


def _tree(rows: list[str]) -> list[str]:
    return [("└ " if i == len(rows) - 1 else "├ ") + row for i, row in enumerate(rows)]


def _visible(s: str) -> int:
    return len(html.unescape(re.sub(r"<[^>]+>", "", s)))


def fmt_amount(x: float) -> str:
    for div, suf in ((1e12, "T"), (1e9, "B"), (1e6, "M"), (1e3, "K")):
        if x >= div:
            return f"{x / div:.2f}".rstrip("0").rstrip(".") + suf
    return f"{x:,.0f}"


class DeployFeed:
    def __init__(self, store, scanner, http: httpx.AsyncClient):
        self.store = store
        self.scanner = scanner
        self.http = http
        self.head = 0
        self.cursor = 0
        self.last_ok = 0.0
        store.db.executescript("""
            CREATE TABLE IF NOT EXISTS deploys (token TEXT PRIMARY KEY, dev TEXT, factory TEXT, ts REAL,
                                                name TEXT, symbol TEXT, ath REAL DEFAULT 0, posted INTEGER DEFAULT 0);
            CREATE INDEX IF NOT EXISTS deploys_dev ON deploys(dev);
        """)
        store.db.commit()

    # ---------- settings ----------
    def channel(self):
        v = self.store.kv_get("deploy_channel") or os.environ.get("DEPLOY_CHANNEL", "")
        if not v:
            return None
        return int(v) if v.lstrip("-").isdigit() else v

    # ---------- NEAR RPC ----------
    async def _rpc(self, params: dict):
        payload = {"jsonrpc": "2.0", "id": "1", "method": "query", "params": params}
        for url in RPC_URLS:
            try:
                r = await self.http.post(url, json=payload)
                data = r.json()
            except (httpx.HTTPError, ValueError):
                continue
            if "result" in data:
                return data["result"]
            if "error" in data:  # account / method doesn't exist — no point asking another RPC
                return None
        return None

    async def view(self, account: str, method: str, args: dict | None = None):
        res = await self._rpc({"request_type": "call_function", "finality": "final", "account_id": account,
                               "method_name": method,
                               "args_base64": base64.b64encode(json.dumps(args or {}).encode()).decode()})
        if not res or res.get("error") or "result" not in res:
            return None
        try:
            return json.loads(bytes(res["result"]).decode())
        except ValueError:
            return None

    async def near_balance(self, account: str) -> float | None:
        res = await self._rpc({"request_type": "view_account", "finality": "final", "account_id": account})
        try:
            return int(res["amount"]) / 1e24
        except (TypeError, KeyError, ValueError):
            return None

    # ---------- block reader ----------
    async def _get_json(self, url: str):
        """(ok, data). ok=False → network/server problem, retry later."""
        try:
            r = await self.http.get(url, follow_redirects=True, timeout=30)
        except httpx.HTTPError as e:
            log.info("neardata %s: %s", url, e)
            return False, None
        if r.status_code == 404:
            return True, None
        if r.status_code >= 400:
            log.info("neardata %s -> HTTP %s", url, r.status_code)
            return False, None
        try:
            return True, r.json()
        except ValueError:
            return False, None

    async def final_height(self) -> int:
        ok, data = await self._get_json(f"{NEARDATA}/v0/last_block/final")
        try:
            return int(data["block"]["header"]["height"]) if ok and data else 0
        except (TypeError, KeyError, ValueError):
            return 0

    async def block(self, h: int):
        return await self._get_json(f"{NEARDATA}/v0/block/{h}")

    async def follow(self, bot):
        """Endless loop: read blocks one after another, post new deploys."""
        await asyncio.sleep(5)
        self.cursor = int(self.store.kv_get("deploy_cursor") or 0)
        start_head = 0
        saved = 0
        while True:
            try:
                if not self.head or self.cursor > self.head:
                    self.head = await self.final_height() or self.head
                    if not self.head:
                        await asyncio.sleep(3)
                        continue
                    if not start_head:
                        start_head = self.head
                        if BACKFILL_DAYS > 0 and not self.store.kv_get("deploy_backfill_done"):
                            asyncio.create_task(self.backfill(start_head))
                    if not self.cursor:
                        self.cursor = self.head
                    if self.cursor > self.head:
                        await asyncio.sleep(1)
                        continue
                if self.head - self.cursor > MAX_LAG_BLOCKS:
                    log.warning("Deploys: %d blocks behind, jumping to the head", self.head - self.cursor)
                    self.cursor = self.head - 5
                n = max(1, min(8, self.head - self.cursor + 1))
                heights = list(range(self.cursor, self.cursor + n))
                results = await asyncio.gather(*(self.block(h) for h in heights))
                for h, (ok, blk) in zip(heights, results):
                    if not ok:
                        break  # retry from this height
                    if blk:
                        for d in parse_block(blk):
                            await self.on_deploy(bot, d, live=True)
                    self.cursor = h + 1
                    self.last_ok = time.time()
                if not all(ok for ok, _ in results):
                    await asyncio.sleep(3)
                if self.cursor - saved >= 50:
                    saved = self.cursor
                    self.store.kv_set("deploy_cursor", str(self.cursor))
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("Deploys loop error")
                await asyncio.sleep(5)

    async def backfill(self, from_height: int):
        """Once: scan the last BACKFILL_DAYS days of blocks to learn older deploys (no posts)."""
        end = int(self.store.kv_get("deploy_backfill_cursor") or from_height)
        stop = from_height - int(BACKFILL_DAYS * 86400 / SECONDS_PER_BLOCK)
        log.info("Deploys backfill: blocks %d → %d", end, stop)
        found = 0
        h = end
        while h > stop:
            heights = list(range(h, max(stop, h - 6), -1))
            results = await asyncio.gather(*(self.block(x) for x in heights))
            if not all(ok for ok, _ in results):
                await asyncio.sleep(5)
                continue
            for ok, blk in results:
                for d in parse_block(blk or {}):
                    if await self.on_deploy(None, d, live=False):
                        found += 1
            h = heights[-1] - 1
            if h % 300 < 6:
                self.store.kv_set("deploy_backfill_cursor", str(h))
            await asyncio.sleep(0.2)  # don't starve the live feed
        self.store.kv_set("deploy_backfill_done", "1")
        log.info("Deploys backfill done: %d deploys found", found)

    # ---------- deploy handling ----------
    async def on_deploy(self, bot, d: dict, live: bool) -> bool:
        dev = d["signer"]
        if not dev or dev in FACTORIES:
            dev = d["predecessor"] if d["predecessor"] not in FACTORIES else ""
        known = self.store.q("SELECT 1 FROM deploys WHERE token=?", (d["token"],))
        if known:
            return False
        self.store.q("INSERT OR IGNORE INTO deploys (token, dev, factory, ts) VALUES (?,?,?,?)",
                     (d["token"], dev, d["factory"], d["ts"]))
        log.info("Deploy: %s by %s", d["token"], dev)
        if live and bot:
            asyncio.create_task(self._post_later(bot, d["token"]))
        else:  # backfill: fill in name/ticker quietly
            meta = await self.view(d["token"], "ft_metadata")
            if isinstance(meta, dict):
                self.store.q("UPDATE deploys SET name=?, symbol=? WHERE token=?",
                             (str(meta.get("name") or "")[:60], str(meta.get("symbol") or "")[:20], d["token"]))
        return True

    async def _post_later(self, bot, token: str):
        await asyncio.sleep(DEPLOY_DELAY)
        ch = self.channel()
        if not ch:
            log.info("Deploy %s: no channel set (/setdeploys)", token)
            return
        try:
            text, image, kb = await self.build(token, bot.username)
            if text is None:
                return
            await self.send(bot, ch, text, image, kb)
            self.store.q("UPDATE deploys SET posted=1 WHERE token=?", (token,))
        except Exception:
            log.exception("Deploy post %s failed", token)

    async def creator_from_nearblocks(self, token: str) -> tuple[str, float]:
        """Who signed the transaction that created the token account (NearBlocks). → (dev, unix time)."""
        hdr = {"Authorization": f"Bearer {NEARBLOCKS_KEY}"} if NEARBLOCKS_KEY else {}
        try:
            r = await self.http.get(f"{NEARBLOCKS}/v1/account/{token}", headers=hdr, timeout=15)
            acc = ((r.json() or {}).get("account") or [{}])[0] if r.status_code < 400 else {}
            created = acc.get("created") or {}
            tx = created.get("transaction_hash")
            ts = int(created.get("block_timestamp") or 0) / 1e9
            if not tx:
                log.info("NearBlocks: no creation tx for %s (HTTP %s)", token, r.status_code)
                return "", 0
            r = await self.http.get(f"{NEARBLOCKS}/v1/txns/{tx}", headers=hdr, timeout=15)
            txns = (r.json() or {}).get("txns") or [] if r.status_code < 400 else []
            signer = (txns[0].get("signer_account_id") or txns[0].get("predecessor_account_id") or "") if txns else ""
            return ("" if signer in FACTORIES else signer), ts
        except (httpx.HTTPError, ValueError, AttributeError, IndexError, TypeError) as e:
            log.info("NearBlocks creator lookup %s: %s", token, e)
            return "", 0

    async def guess_dev(self, token: str) -> str:
        """Token deployed before tracking: find who created it and remember it."""
        dev, ts = await self.creator_from_nearblocks(token)
        if dev:
            self.store.q("INSERT OR IGNORE INTO deploys (token, dev, factory, ts) VALUES (?,?,?,?)",
                         (token, dev, factory_of(token) or "", ts or time.time()))
            self.store.q("UPDATE deploys SET dev=? WHERE token=? AND (dev IS NULL OR dev='')", (dev, token))
            return dev
        for m in ("get_owner", "owner", "owner_id", "get_creator", "creator", "get_owner_id"):
            v = await self.view(token, m)
            if isinstance(v, dict):
                v = v.get("owner_id") or v.get("creator") or v.get("owner")
            if isinstance(v, str) and v and v not in FACTORIES and not v.endswith(tuple(FACTORIES)):
                return v
        return ""

    async def token_ath(self, token: str) -> float:
        row = self.store.q("SELECT ath FROM deploys WHERE token=?", (token,))
        best = float(row[0][0] or 0) if row else 0.0
        try:
            c = await self.scanner.card(token, with_chart=True)
        except Exception:
            c = None
        if c:
            best = max(best, c.ath_mcap, c.fdv)
            if row:
                self.store.q("UPDATE deploys SET ath=? WHERE token=?", (best, token))
        return best

    async def _reference(self, meta: dict) -> dict:
        ref = meta.get("reference") or ""
        if ref.startswith("ipfs://"):
            ref = "https://ipfs.io/ipfs/" + ref[7:]
        if not ref.startswith("http"):
            return {}
        try:
            r = await self.http.get(ref, timeout=8, follow_redirects=True)
            data = r.json()
            return data if isinstance(data, dict) else {}
        except (httpx.HTTPError, ValueError):
            return {}

    async def _image(self, icon: str):
        if not icon:
            return None
        if icon.startswith("data:"):
            head, _, body = icon.partition(",")
            try:
                raw = base64.b64decode(body) if ";base64" in head else body.encode()
            except ValueError:
                return None
            return self._svg_to_png(raw) if "svg" in head else raw
        if icon.startswith("ipfs://"):
            icon = "https://ipfs.io/ipfs/" + icon[7:]
        if not icon.startswith("http"):
            return None
        try:
            r = await self.http.get(icon, timeout=10, follow_redirects=True)
        except httpx.HTTPError:
            return None
        if r.status_code >= 400 or len(r.content) > 8_000_000:
            return None
        ctype = r.headers.get("content-type", "")
        if "svg" in ctype or r.content.lstrip()[:5] in (b"<?xml", b"<svg "):
            return self._svg_to_png(r.content)
        return r.content if ctype.startswith("image/") or r.content[:4] in (b"\x89PNG", b"RIFF", b"GIF8") \
            or r.content[:2] == b"\xff\xd8" else None

    @staticmethod
    def _svg_to_png(raw: bytes):
        try:
            import cairosvg
            return cairosvg.svg2png(bytestring=raw, output_width=512, output_height=512)
        except Exception:
            return None

    async def build(self, token: str, bot_username: str, dev: str | None = None):
        """(text, image bytes or None, keyboard) for one deploy."""
        meta = None
        for _ in range(4):  # metadata can appear a few seconds after the account
            meta = await self.view(token, "ft_metadata")
            if isinstance(meta, dict):
                break
            await asyncio.sleep(4)
        if not isinstance(meta, dict):
            log.info("Deploy %s: no ft_metadata, skipping", token)
            return None, None, None
        row = self.store.q("SELECT dev, factory FROM deploys WHERE token=?", (token,))
        fac = row[0][1] if row else (factory_of(token) or "")
        if dev is None:
            dev = (row[0][0] if row else "") or await self.guess_dev(token)
        name = str(meta.get("name") or "?")[:60]
        symbol = str(meta.get("symbol") or "?")[:20]
        decimals = int(meta.get("decimals") or 0)
        self.store.q("UPDATE deploys SET name=?, symbol=? WHERE token=?", (name, symbol, token))
        supply_raw = await self.view(token, "ft_total_supply")
        try:
            supply_raw = int(supply_raw)
        except (TypeError, ValueError):
            supply_raw = 0
        extra = await self._reference(meta)
        desc = str(meta.get("description") or extra.get("description") or "").strip()
        socials = {k: extra.get(k) for k in ("website", "twitter", "telegram") if isinstance(extra.get(k), str)}

        label, page_tpl = FACTORIES.get(fac, ("NEAR", "https://nearblocks.io/token/{a}"))
        e = html.escape
        lines = [f"🚀 <b>{label} DEPLOY!</b>", "", "🏦 <b>Token Info</b>", f"<code>{e(token)}</code>"]
        info = [f"Name: <b>{e(name)}</b>", f"Ticker: <b>${e(symbol)}</b>"]
        if desc:
            info.append(f"Description: <i>{e(desc[:280])}{'…' if len(desc) > 280 else ''}</i>")
        if supply_raw:
            info.append(f"Supply: {fmt_amount(supply_raw / 10 ** decimals)}")
        links = []
        for k, icon in (("website", "🌐"), ("twitter", "𝕏"), ("telegram", "✈️")):
            v = socials.get(k, "")
            if v.startswith("http"):
                links.append(f'<a href="{e(v)}">{icon} {k.capitalize()}</a>')
        if links:
            info.append(" · ".join(links))
        lines += _tree(info)

        lines += ["", "💰 <b>Dev Info</b>"]
        if dev:
            lines.append(f'<a href="https://nearblocks.io/address/{e(dev)}"><code>{e(dev)}</code></a>')
            prev = self.store.q("SELECT token, symbol, factory FROM deploys WHERE dev=? AND token<>? "
                                "ORDER BY ts DESC", (dev, token))
            bal, held, aths = await asyncio.gather(
                self.near_balance(dev),
                self.view(token, "ft_balance_of", {"account_id": dev}),
                asyncio.gather(*(self.token_ath(p[0]) for p in prev[:6])))
            dev_rows = []
            if prev:
                names = []
                for t, sym, f in prev[:5]:
                    tpl = FACTORIES.get(f, (None, "https://nearblocks.io/token/{a}"))[1]
                    names.append(f'<a href="{e(tpl.format(a=t))}">{e(sym or t.split(".")[0].upper())}</a>')
                more = f" +{len(prev) - 5}" if len(prev) > 5 else ""
                dev_rows.append(f"🕑 Deploys: {len(prev)} ({', '.join(names)}{more})")
                best_i = max(range(len(aths)), key=lambda i: aths[i]) if aths else None
                if best_i is not None and aths[best_i] > 0:
                    t, sym, _ = prev[best_i]
                    dev_rows.append(f"🏆 Best ATH: <b>{usd(aths[best_i])}</b> ({e(sym or t.split('.')[0].upper())})")
                else:
                    dev_rows.append("🏆 Best ATH: —")
            else:
                dev_rows.append("🆕 First deploy from this wallet" if self.store.kv_get("deploy_backfill_done")
                                else "🆕 No previous deploys found")
            if bal is not None:
                dev_rows.append(f"Ⓝ NEAR Balance: <b>{bal:,.2f} NEAR</b>")
            try:
                held = int(held)
            except (TypeError, ValueError):
                held = None
            if held is not None and supply_raw:
                dev_rows.append(f"🪙 Dev holds: <b>{held * 100 / supply_raw:.2f}%</b>")
            lines += _tree(dev_rows)
        else:
            lines.append("└ creator not found")

        key = self.store.scan_key(token)
        kb_rows = [[InlineKeyboardButton("🟢 Buy on Bettear", url=buy_link(token)),
                    InlineKeyboardButton({"NEARLY": "Nearly", "JUSTHOOT": "JustHoot"}.get(label, label.title()), url=page_tpl.format(a=token))]]
        second = []
        if bot_username:
            second.append(InlineKeyboardButton("🔎 Scan", url=f"https://t.me/{bot_username}?start=sc_{key}"))
        if dev:
            second.append(InlineKeyboardButton("👤 Dev", url=f"https://nearblocks.io/address/{dev}"))
        if second:
            kb_rows.append(second)

        text = "\n".join(lines)
        image = await self._image(str(meta.get("icon") or ""))
        return text, image, InlineKeyboardMarkup(kb_rows)

    async def send(self, bot, chat_id, text: str, image, kb):
        kw = dict(chat_id=chat_id, parse_mode=ParseMode.HTML, reply_markup=kb)
        if image and _visible(text) <= 1024:
            try:
                return await bot.send_photo(photo=image, caption=text, **kw)
            except Exception as ex:
                log.info("Deploy photo failed (%s), sending text", ex)
        return await bot.send_message(text=text, link_preview_options=NO_PREVIEW, **kw)

    # ---------- ATH tracking ----------
    async def track_ath(self, _ctx=None):
        """Every few minutes: record the highest market cap of recently deployed tokens (for 'Best ATH')."""
        since = time.time() - ATH_TRACK_DAYS * 86400
        tokens = [r[0] for r in self.store.q("SELECT token FROM deploys WHERE ts>?", (since,))]
        for i in range(0, len(tokens), 30):
            try:
                r = await self.http.get(f"{DEXS}/tokens/v1/near/" + ",".join(tokens[i:i + 30]))
                data = r.json() if r.status_code < 400 else []
            except (httpx.HTTPError, ValueError):
                continue
            best: dict[str, float] = {}
            for p in data if isinstance(data, list) else []:
                a = (p.get("baseToken") or {}).get("address")
                try:
                    mc = float(p.get("marketCap") or p.get("fdv") or 0)
                except (TypeError, ValueError):
                    continue
                if a:
                    best[a] = max(best.get(a, 0), mc)
            for a, mc in best.items():
                self.store.q("UPDATE deploys SET ath=MAX(COALESCE(ath,0), ?) WHERE token=?", (mc, a))

    def status(self) -> str:
        n = self.store.q("SELECT COUNT(*), COUNT(DISTINCT dev) FROM deploys")[0]
        last = self.store.q("SELECT token, ts FROM deploys ORDER BY ts DESC LIMIT 1")
        lag = max(0, self.head - self.cursor) if self.head and self.cursor else None
        ch = self.channel()
        bf = "done" if self.store.kv_get("deploy_backfill_done") else (
            f"running ({BACKFILL_DAYS:g} days)" if BACKFILL_DAYS > 0 else "off")
        out = [f"📡 Channel: <code>{html.escape(str(ch))}</code>" if ch else "📡 Channel: not set — /setdeploys @channel",
               f"🧱 Block: {self.cursor or '—'}" + (f" (behind by {lag})" if lag is not None else ""),
               f"🗂 Deploys stored: {n[0]} from {n[1]} devs",
               f"⏪ Backfill: {bf}"]
        if last:
            out.append(f"🆕 Last: <code>{html.escape(last[0][0])}</code> "
                       f"{int((time.time() - last[0][1]) // 60)} min ago")
        return "\n".join(out)
