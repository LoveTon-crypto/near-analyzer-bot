"""Wallet PnL ("Inspect Wallet") for any NEAR account.

Data: Intear API (https://api.intea.rs, free during beta, no key):
  • /positions — every token position built from the wallet's swaps: bought/sold USD, realized PnL, amount left
  • /trades    — swaps of the last 7 days (for the 7d block)
  • /balances  — tokens held now + prices (to value what's still held)
NEAR balance comes from public NEAR RPC (no FastNear key used).
"""
from __future__ import annotations

import asyncio
import base64
import html
import json
import logging
import time

import httpx

log = logging.getLogger("wallet")

INTEAR = "https://api.intea.rs"
RPC_URLS = ["https://rpc.mainnet.fastnear.com", "https://free.rpc.fastnear.com", "https://rpc.mainnet.near.org"]
# quote tokens — not "positions" in the memecoin sense
BASES = {"wrap.near", "near", "usdt.tether-token.near",
         "17208628f84f5d6ad33f0da3bbbeb27ffcb398eac501a31bd6ad2011e36133a1",  # USDC
         "a0b86991c6218b36c1d19d4a2e9eb0ce3606eb48.factory.bridge.near",       # USDC.e
         "dac17f958d2ee523a2206206994597c13d831ec7.factory.bridge.near"}       # USDT.e


def _table(data) -> list[dict]:
    """Intear answers {result: {columns, rows}} (or the inner object directly); rows may be lists or dicts."""
    if isinstance(data, dict) and "result" in data:
        data = data["result"]
    if isinstance(data, list):
        return [r for r in data if isinstance(r, dict)]
    if not isinstance(data, dict):
        return []
    rows = data.get("rows") or data.get("positions") or data.get("trades") or []
    cols = data.get("columns") or []
    out = []
    for r in rows:
        if isinstance(r, dict):
            out.append(r)
        elif isinstance(r, list) and cols:
            out.append(dict(zip(cols, r)))
    return out


def f(x) -> float:
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def money(x: float) -> str:
    sign = "-" if x < 0 else ""
    x = abs(x)
    for div, suf in ((1e9, "B"), (1e6, "M"), (1e3, "K")):
        if x >= div:
            return f"{sign}${x / div:.2f}".rstrip("0").rstrip(".") + suf
    return f"{sign}${x:,.2f}"


def signed(x: float) -> str:
    return ("+" if x >= 0 else "") + money(x)


def nears(x_usd: float, near_usd: float) -> str:
    if near_usd <= 0:
        return ""
    v = x_usd / near_usd
    return f" <i>≈{v:,.0f} Ⓝ</i>" if abs(v) >= 100 else f" <i>≈{v:,.1f} Ⓝ</i>"


class WalletPnL:
    def __init__(self, http: httpx.AsyncClient):
        self.http = http
        self._sym: dict[str, str] = {}

    async def _get(self, path: str, params: dict, timeout: float = 25):
        try:
            r = await self.http.get(f"{INTEAR}{path}", params=params, timeout=timeout)
        except httpx.HTTPError as e:
            log.info("intear %s: %s", path, e)
            return None
        if r.status_code >= 400:
            log.info("intear %s -> HTTP %s %s", path, r.status_code, r.text[:200])
            return None
        try:
            return r.json()
        except ValueError:
            return None

    async def _rpc(self, params: dict):
        payload = {"jsonrpc": "2.0", "id": "1", "method": "query", "params": params}
        for url in RPC_URLS:
            try:
                data = (await self.http.post(url, json=payload, timeout=10)).json()
            except (httpx.HTTPError, ValueError):
                continue
            if "result" in data:
                return data["result"]
            if "UNKNOWN_ACCOUNT" in json.dumps(data.get("error") or ""):
                return None
        return None

    async def account(self, acc: str):
        res = await self._rpc({"request_type": "view_account", "finality": "final", "account_id": acc})
        return res if isinstance(res, dict) and "amount" in res else None

    async def symbol(self, token: str) -> str:
        if token in self._sym:
            return self._sym[token]
        res = await self._rpc({"request_type": "call_function", "finality": "final", "account_id": token,
                               "method_name": "ft_metadata", "args_base64": base64.b64encode(b"{}").decode()})
        sym = ""
        try:
            sym = str(json.loads(bytes(res["result"]).decode()).get("symbol") or "")[:16]
        except (TypeError, KeyError, ValueError, AttributeError):
            pass
        sym = sym or token.split(".")[0].upper()[:16]
        self._sym[token] = sym
        return sym

    async def positions(self, acc: str) -> list[dict] | None:
        data = await self._get("/positions", {"account": acc, "limit": 1000})
        return None if data is None else _table(data)

    async def balances(self, acc: str) -> dict[str, tuple[float, str]]:
        """token -> (USD value now, symbol)."""
        data = await self._get("/balances", {"account": acc, "sources": "direct",
                                             "token_fields": "symbol,decimals,price_usd"})
        if isinstance(data, dict) and "result" in data:
            data = data["result"]
        if not isinstance(data, dict):
            return {}
        toks = data.get("tokens") or {}
        bal_rows = _table(data.get("balances") or [])
        out: dict[str, tuple[float, str]] = {}
        for r in bal_rows:
            t = r.get("token")
            meta = toks.get(t) or {}
            if not t:
                continue
            dec = int(f(meta.get("decimals")))
            val = f(r.get("balance")) / 10 ** dec * f(meta.get("price_usd"))
            sym = str(meta.get("symbol") or "")
            if sym:
                self._sym[t] = sym[:16]
            old = out.get(t, (0.0, sym))
            out[t] = (old[0] + val, sym or old[1])
        return out

    async def trades_7d(self, acc: str) -> list[dict]:
        since = int((time.time() - 7 * 86400) * 1000)
        rows, cursor = [], None
        for _ in range(10):  # up to 2000 swaps
            params = {"trader": acc, "after_millis": since, "limit": 200, "order": "desc",
                      "fields": "id,side,token,usd_value,timestamp_millis"}
            if cursor:
                params["cursor"] = cursor
            data = await self._get("/trades", params)
            if data is None:
                break
            inner = data.get("result", data) if isinstance(data, dict) else {}
            rows += _table(data)
            cursor = inner.get("next_cursor") if isinstance(inner, dict) else None
            if not cursor:
                break
        return rows

    # ------------------------------------------------------------------
    async def report(self, acc: str, near_usd: float) -> str | None:
        """HTML text of the wallet report, or None if the account doesn't exist."""
        info = await self.account(acc)
        if info is None:
            return None
        pos, bals, tr7 = await asyncio.gather(self.positions(acc), self.balances(acc), self.trades_7d(acc))
        near_bal = f(info.get("amount")) / 1e24
        e = html.escape
        held_value = sum(v for t, (v, _) in bals.items() if t not in BASES)
        wnear = bals.get("wrap.near", (0.0, ""))[0]

        lines = ["🔎 <b>Inspect Wallet</b>", "",
                 f'👛 Wallet: <a href="https://nearblocks.io/address/{e(acc)}"><code>{e(acc)}</code></a>',
                 f"Ⓝ NEAR: <b>{near_bal:,.2f}</b>" + (f" ≈ {money(near_bal * near_usd)}" if near_usd else "")
                 + (f" (+ {money(wnear)} wNEAR)" if wnear >= 1 else ""),
                 f"💰 Tokens value: <b>{money(held_value)}</b>"]

        if pos is None:
            lines += ["", "⚠️ Trade history service is not answering right now, try again in a minute."]
            return "\n".join(lines)

        pos = [p for p in pos if p.get("token") and p["token"] not in BASES]
        if not pos:
            lines += ["", "🤷 No swaps found for this wallet."]
            return "\n".join(lines)

        # ----- all time
        rows = []
        for p in pos:
            t = p["token"]
            hold = bals.get(t, (0.0, ""))[0]
            b, s = f(p.get("bought_usd")), f(p.get("sold_usd"))
            rows.append((t, b, s, hold, s + hold - b, p))
        B = sum(r[1] for r in rows)
        S = sum(r[2] for r in rows)
        Hh = sum(r[3] for r in rows)
        P = S + Hh - B
        realized = sum(f(r[5].get("realized_pnl_usd")) for r in rows)
        wins = sum(1 for r in rows if r[4] > 0)
        traded = [r for r in rows if r[1] > 0]
        buys = sum(int(f(r[5].get("buys"))) for r in rows)
        sells = sum(int(f(r[5].get("sells"))) for r in rows)
        lines += ["", "🚀 <b>Total PnL</b>", "<blockquote>"
                  f"📥 Bought: <b>{money(B)}</b>{nears(B, near_usd)}\n"
                  f"📦 Hold: <b>{money(Hh)}</b>{nears(Hh, near_usd)}\n"
                  f"✅ Sold: <b>{money(S)}</b>{nears(S, near_usd)}\n"
                  f"{'🟢' if P >= 0 else '🔴'} PnL: <b>{signed(P)}</b>"
                  + (f" <b>{P / B * 100:+.0f}%</b>" if B > 0 else "") + "\n"
                  f"💵 Realized: {signed(realized)}\n"
                  f"🎯 Win rate: <b>{wins}/{len(traded)}</b> tokens"
                  + (f" ({wins / len(traded) * 100:.0f}%)" if traded else "")
                  + f" · {buys} buys / {sells} sells</blockquote>"]

        # ----- 7 days
        if tr7:
            b7 = sum(f(x.get("usd_value")) for x in tr7 if str(x.get("side")).lower() == "buy")
            s7 = sum(f(x.get("usd_value")) for x in tr7 if str(x.get("side")).lower() == "sell")
            toks7 = {x.get("token") for x in tr7 if str(x.get("side")).lower() == "buy"} - BASES
            h7 = sum(bals.get(t, (0.0, ""))[0] for t in toks7)
            p7 = s7 + h7 - b7
            lines += ["😬 <b>7d PnL</b>" if p7 < 0 else "😎 <b>7d PnL</b>", "<blockquote>"
                      f"📥 Bought: <b>{money(b7)}</b>{nears(b7, near_usd)}\n"
                      f"📦 Hold: <b>{money(h7)}</b>{nears(h7, near_usd)}\n"
                      f"✅ Sold: <b>{money(s7)}</b>{nears(s7, near_usd)}\n"
                      f"{'🟢' if p7 >= 0 else '🔴'} PnL: <b>{signed(p7)}</b>"
                      + (f" <b>{p7 / b7 * 100:+.0f}%</b>" if b7 > 0 else "")
                      + f" · {len(tr7)} swaps</blockquote>"]
        else:
            lines += ["😴 <b>7d PnL</b>: no swaps in the last 7 days"]

        # ----- best / worst tokens
        ranked = sorted(traded, key=lambda r: r[4], reverse=True)
        best = [r for r in ranked if r[4] > 0][:3]
        worst = [r for r in reversed(ranked) if r[4] < 0][:3]
        syms = await asyncio.gather(*(self.symbol(r[0]) for r in best + worst))
        sm = dict(zip([r[0] for r in best + worst], syms))
        if best:
            lines.append("🏆 Best: " + " · ".join(
                f"<b>${e(sm[r[0]])}</b> {signed(r[4])}" + (f" ({r[4] / r[1] * 100:+.0f}%)" if r[1] else "")
                for r in best))
        if worst:
            lines.append("💀 Worst: " + " · ".join(
                f"<b>${e(sm[r[0]])}</b> {signed(r[4])}" + (f" ({r[4] / r[1] * 100:+.0f}%)" if r[1] else "")
                for r in worst))
        lines.append("<i>USD at trade time · Hold = current value</i>")
        return "\n".join(lines)
